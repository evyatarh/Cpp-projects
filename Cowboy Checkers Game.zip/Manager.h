/*
 * Manager.h
 *
 *  Created on: Apr 17, 2018
 *      Author: cs203784939
 */

#ifndef MANAGER_H_
#define MANAGER_H_

#include "Board.h"
#include <cstdlib>

class Manager {

private:

	Board gameBoard;
	Player first;
	Player sec;
	int const static MAXROUNDS = 9;

public:
	Manager();
	Player getFirstPlayer()const;
	Player getSeconedPlayer()const;
	void firstSets();//the first posting of the game
	void play(); //the game play

	~Manager(){};
};

#endif /* MANAGER_H_ */
