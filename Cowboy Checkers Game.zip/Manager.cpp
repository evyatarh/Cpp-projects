/*
 * Manager.cpp
 *
 *  Created on: Apr 17, 2018
 *      Author: cs203784939
 */

#include "Manager.h"

/******************** c'tor method **************************/
Manager::Manager()
:gameBoard(),first('B'),sec('W')
{}

/******************** firstSets method **************************/
void Manager::firstSets(){


	bool flag = true;
	int rounds = 0;
	int loc = 0;
	Point coordinate;
	Point help(-1,-1); //for help spot

	gameBoard.initilaizeBoard();
	gameBoard.printBoard();

	while(rounds++< MAXROUNDS){


		gameBoard.getPoints(flag,coordinate,first); //get points from the user
		loc = first.emptySpotForDisc(coordinate); //checking for a new empty place in the disc array
		first.setDisc(gameBoard.initalizePlayerDisc(coordinate),loc); //set the disc in the array

		if(!flag){ gameBoard.message(sec.getColor(),first.getColor());exit(1);} //flag change to be false if the user entered "QUIT"
																			   // then the message will be printed

		gameBoard.setCharBoardCordinate(first.getColor(),first.getDisc(loc).getLocation()); //set the color in the game board
		gameBoard.printBoard();

		if(gameBoard.checkForStrike(first.getDisc(loc).getLocation(),first.getColor())) //checking if there any strikes
		{
			flag = false;
			cout << "B:" << endl;
			gameBoard.getPoints(flag,help,sec);
			if(!flag){ gameBoard.message(sec.getColor(),first.getColor());exit(1);}
			gameBoard.removeDisc(sec,help); //removing the specific spot of the other player
			sec.decDiscs(); //dec the seconed player discs
			gameBoard.printBoard();

		}

		first.incDiscs();


		gameBoard.getPoints(flag,coordinate,sec);
		loc = sec.emptySpotForDisc(coordinate);
		sec.setDisc(gameBoard.initalizePlayerDisc(coordinate),loc);

		if(!flag){ gameBoard.message(first.getColor(),sec.getColor());exit(1);}

		gameBoard.setCharBoardCordinate(sec.getColor(),sec.getDisc(loc).getLocation());
		gameBoard.printBoard();

		if(gameBoard.checkForStrike(sec.getDisc(loc).getLocation(),sec.getColor()))
		{
			flag = false;
			cout << "W:" << endl;
			gameBoard.getPoints(flag,help,first);
			if(!flag){ gameBoard.message(first.getColor(),sec.getColor());exit(1);}
			gameBoard.removeDisc(first,help);
			first.decDiscs();
			gameBoard.printBoard();

		}

		sec.incDiscs();

	}

}

/******************** play method **************************/
void Manager::play(){

	Point currentCoordinate;
	Point nextCoordinate;
	DiscTool disc;
	bool flag = true;
	int spot = 0;
	Point temp(-1,-1);

	while(true){

		gameBoard.getPoints(currentCoordinate,nextCoordinate,flag,first);

		if(!flag){ gameBoard.message(sec.getColor(),first.getColor());exit(1);}

		gameBoard.removeDisc(first,currentCoordinate); //the disc who move place
		disc = gameBoard.initalizePlayerDisc(nextCoordinate);
		spot = first.emptySpotForDisc(currentCoordinate);
		disc.setLocation(nextCoordinate);
		first.setDisc(disc,spot); //put the disc at the new place
		gameBoard.setCharBoardCordinate(first.getColor(),first.getDisc(spot).getLocation());
		gameBoard.printBoard();

		if(gameBoard.checkForStrike(first.getDisc(spot).getLocation(),first.getColor()))
		{
			flag = false;
			cout << "B:" << endl;
			gameBoard.getPoints(flag,temp,sec);
			if(!flag){ gameBoard.message(sec.getColor(),first.getColor());exit(1);}
			gameBoard.removeDisc(sec,temp);
			sec.decDiscs();
			gameBoard.printBoard();

		}

		if(sec.getCurrNumOfDiscs()==3){ //if the player get to 3 discs he will lose the game
			cout << "B wins the game.";
			return;
		}

		gameBoard.getPoints(currentCoordinate,nextCoordinate,flag,sec);

		if(!flag){ gameBoard.message(first.getColor(),sec.getColor());exit(1);}

		gameBoard.removeDisc(sec,currentCoordinate);
		disc = gameBoard.initalizePlayerDisc(nextCoordinate);
		spot = sec.emptySpotForDisc(currentCoordinate);
		disc.setLocation(nextCoordinate);
		sec.setDisc(disc,spot);
		gameBoard.setCharBoardCordinate(sec.getColor(),sec.getDisc(spot).getLocation());
		gameBoard.printBoard();

		if(gameBoard.checkForStrike(sec.getDisc(spot).getLocation(),sec.getColor()))
		{
			flag = false;
			cout << "W:" << endl;
			gameBoard.getPoints(flag,temp,first);
			if(!flag){ gameBoard.message(first.getColor(),sec.getColor());exit(1);}
			gameBoard.removeDisc(first,temp);
			first.decDiscs();
			gameBoard.printBoard();

		}

		if(first.getCurrNumOfDiscs()==3){
			cout << "W wins the game.";
			return;
		}

	}
}


/******************** getFirstPlayer method **************************/
Player Manager::getFirstPlayer()const {return first;}


/******************** getSeconedPlayer method **************************/
Player Manager::getSeconedPlayer()const {return sec;}



