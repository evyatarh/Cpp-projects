/*
 * Point.cpp
 *
 *  Created on: Apr 17, 2018
 *      Author: cs203784939
 */

#include "Point.h"

/******************** c'tor method **************************/
Point::Point(const int &x,const int &y):x(x),y(y)
{}

/******************** c'tor method **************************/
Point::Point():x(0),y(0)
{}

/******************** copy c'tor method **************************/
Point::Point(const Point &loc):x(loc.x),y(loc.y)
{}

/******************** equal method **************************/
bool Point::equal(const Point &a)const{

	if((this->x==a.getX())&&(this->y==a.getY()))return true;
	return false;
}

/******************** equal method **************************/
bool Point::equal(const int &a,const int &b)const{

	if((this->x==a)&&(this->y==b))return true;
	return false;
}

/******************** setX method **************************/
void Point::setX(const char &x) {this->x=x;}

/******************** setY method **************************/
void Point::setY(const char &y) {this->y=y;}

/******************** setPoint method **************************/
void Point::setPoint(const Point &point){
	this->x = point.getX();
	this->y = point.getY();
}

/******************** getX method **************************/
char Point::getX()const {return x;}

/******************** getY method **************************/
char Point::getY()const {return y;}

/******************** convertFromCharToInt method **************************/
int Point::convertFromCharToInt(const char &someChar)const { return (someChar-'a');}

/******************** convertFromCharToNum method **************************/
int Point::convertFromCharToNum(const char &someChar)const { return 7-(someChar-'0');}


