/*
 * DiscTool.cpp
 *
 *  Created on: Apr 17, 2018
 *      Author: cs203784939
 */

#include "DiscTool.h"


/******************** c'tor method **************************/
DiscTool::DiscTool():location()
{}


/******************** c'tor method **************************/
DiscTool::DiscTool(const int &a,const int &b):location(a,b)
{}

/******************** c'tor method **************************/
DiscTool::DiscTool(const Point &location):location(location)
{}


/******************** operator method **************************/
Point& DiscTool::operator=(const Point& loc){

	this->location.setX(loc.getX());
	this->location.setY(loc.getY());

	return this->location;
}


/******************** setLocation method **************************/
void DiscTool::setLocation(const Point &location) {this->location=location;}

/******************** getLocation method **************************/
Point DiscTool::getLocation()const {return location;}

