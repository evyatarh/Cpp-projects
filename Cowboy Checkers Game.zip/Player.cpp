/*
 * Player.cpp
 *
 *  Created on: Apr 17, 2018
 *      Author: cs203784939
 */

#include "Player.h"

/******************** c'tor method **************************/
Player::Player(const char &color)
:color(color)
{
	DiscTool reset(-1,-1);
	currNumOfDiscs = 0;

	for(int i=0;i<MAXDISCS;i++) disc[i] = reset;

}

/******************** copy c'tor method **************************/
Player::Player(const Player &player)
:color(player.color)
{

	DiscTool reset(-1,-1);
	currNumOfDiscs = 0;

	for(int i=0;i<MAXDISCS;i++) disc[i] = reset;


}

/******************** setCurrNumOfDiscs method **************************/
void Player::setCurrNumOfDiscs(const int &numOfDiscs) {this->currNumOfDiscs=numOfDiscs;}

/******************** decDiscs method **************************/
void Player::decDiscs() {this->currNumOfDiscs--;}

/******************** incDiscs method **************************/
void Player::incDiscs() {this->currNumOfDiscs++;}

/******************** emptySpotForDisc method **************************/
int Player::emptySpotForDisc(const Point &currentCoordinate)const{

	Point emptyLoc(-1,-1);

	for(int i=0;MAXDISCS;i++){
		if(this->disc[i].getLocation().equal(emptyLoc))
			return i;
		if(this->disc[i].getLocation().equal(currentCoordinate))
			return i;
	}

}

/******************** setDisc method **************************/
void Player::setDisc(const DiscTool &disc,const int &pos) {this->disc[pos]=disc;}

/******************** getCurrNumOfDiscs method **************************/
int Player::getCurrNumOfDiscs()const {return currNumOfDiscs;}

/******************** getDisc method **************************/
DiscTool Player::getDisc(const int &index)const {return disc[index];}

/******************** getColor method **************************/
char Player::getColor()const {return color;}

/******************** getMaxDiscs method **************************/
int Player::getMaxDiscs()const{return MAXDISCS;}


