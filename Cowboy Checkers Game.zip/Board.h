/*
 * Board.h
 *
 *  Created on: Apr 17, 2018
 *      Author: cs203784939
 */

#ifndef BOARD_H_
#define BOARD_H_

#include "Player.h"
#include <iostream>
using namespace std;

class Board {

private:

	int const static SIZE = 7;
	char board[SIZE][SIZE];


public:

	Board();
	bool checkForTrueJunctions(Point &currCoor,Point &nextCoor);
	bool checkForStrike(const Point &a,const char &letter)const;
	bool checkIfItAFreeCoordinate(const Point &point)const;
	bool checkIfItAPlayerRemovel(const Player &player,const Point &point)const;
	void removeDisc(Player &play,Point &temp);
	void getPoints(bool &flag,Point &temp,const Player &player)const; // for the first posting of the game
	void getPoints(Point &first,Point &sec,bool &flag,const Player &player);
	DiscTool initalizePlayerDisc(Point &temp);
	void message(const char &wins,const char &lost)const;
	void setCharBoardCordinate(const char &someChar,const Point &location);
	char getCharInCordinate(const Point &location)const;
	void initilaizeBoard();
	void printBoard()const;
	~Board(){};
};

#endif /* BOARD_H_ */
