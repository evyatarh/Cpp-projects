/*
 * DiscTool.h
 *
 *  Created on: Apr 17, 2018
 *      Author: cs203784939
 */

#ifndef DISCTOOL_H_
#define DISCTOOL_H_

#include "Point.h"

class DiscTool {

private:

	Point location;

public:

	DiscTool(const Point &location);
	DiscTool(const int &a,const int &b);
	DiscTool();
	void setLocation(const Point &location);
	Point getLocation()const;
	Point& operator=(const Point& loc);
	~DiscTool(){};
};

#endif /* DISCTOOL_H_ */
