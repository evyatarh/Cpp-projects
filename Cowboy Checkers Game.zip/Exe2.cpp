//============================================================================
// Name        : Exe2.cpp
// Author      : 
// Version     :
// Copyright   : Evi
// Description : Cowboy Checkers Game
//============================================================================

#include <iostream>
using namespace std;
#include "Manager.h"

int main() {

	Manager m;
	m.firstSets();
	m.play();

	return 0;
}
