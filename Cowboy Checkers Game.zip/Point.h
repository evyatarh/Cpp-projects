/*
 * Point.h
 *
 *  Created on: Apr 17, 2018
 *      Author: cs203784939
 */

#ifndef POINT_H_
#define POINT_H_

class Point {

private:

	int x;
	int y;

public:

	Point(const int &x,const int &y);
	Point();
	Point(const Point &loc);
	void setPoint(const Point &point);
	int convertFromCharToInt(const char &someChar)const;
	int convertFromCharToNum(const char &someChar)const;
	bool equal(const Point &a)const; //check if a Point is equal
	bool equal(const int &a,const int &b)const;
	void setX(const char &x);
	void setY(const char &y);
	char getX()const;
	char getY()const;
	~Point(){};
};

#endif /* POINT_H_ */
