/*
 * Player.h
 *
 *  Created on: Apr 17, 2018
 *      Author: cs203784939
 */

#ifndef PLAYER_H_
#define PLAYER_H_

#include "DiscTool.h"
#include <iostream>
using namespace std;
#include <cmath>

class Player {

private:

	int const static MAXDISCS = 9;
	int currNumOfDiscs;
	DiscTool disc[MAXDISCS];
	char color;

public:

	Player(const char &color);
	Player(const Player &player);
	void decDiscs();
	void incDiscs();
	int emptySpotForDisc(const Point &currentCoordinate)const; //this method checking for empty spot in the
															  //array to put there a new disc or if the disc is already exist
	void setCurrNumOfDiscs(const int &numOfDiscs);
	void setDisc(const DiscTool &disc,const int &pos);
	int getCurrNumOfDiscs()const;
	int getMaxDiscs()const;
	DiscTool getDisc(const int &index)const;
	char getColor()const;
	~Player(){};
};

#endif /* PLAYER_H_ */
