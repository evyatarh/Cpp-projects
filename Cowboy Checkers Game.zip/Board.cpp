/*
 * Board.cpp
 *
 *  Created on: Apr 17, 2018
 *      Author: cs203784939
 */

#include "Board.h"


/******************** c'tor method **************************/
Board::Board()
{}


/******************** initalizePlayerDisc method **************************/
DiscTool Board::initalizePlayerDisc(Point &temp){

	DiscTool discTool;
	discTool.setLocation(temp);
	return discTool;

}

/******************** getPoints method **************************/
void Board::getPoints(bool &flag,Point &temp,const Player &player)const{

	string s;

	while(true){

		if(flag) cout << player.getColor() << ":" << endl;
		cin >> s;

		if(!s.compare("QUIT")){ flag=false;return;}

		if(s.length()==2){

			const char *ptr = s.c_str(); //split the string
			temp.setX(temp.convertFromCharToInt(*ptr));
			temp.setY(temp.convertFromCharToNum(*(ptr+1)));

			if(!flag){
				if(checkIfItAPlayerRemovel(player,temp)){flag = true;return;}
			}
			else if(checkIfItAFreeCoordinate(temp)) return;
		}

		cerr << "Invalid move; the game awaits a valid move.\n";

	}
}


/******************** getPoints method **************************/
void Board::getPoints(Point &first,Point &sec,bool &flag,const Player &player){

	string firstCoordinate,secCoordinate;

	while(true){

		cout << player.getColor() << ":" << endl;

		cin >> firstCoordinate;
		if(!firstCoordinate.compare("QUIT")) {flag=false;return;}

		cin >> secCoordinate;
		if(!secCoordinate.compare("QUIT")) {flag=false;return;}



		if(firstCoordinate.length()!=2 || secCoordinate.length()!=2){
			cerr << "Invalid move; the game awaits a valid move.\n";
			continue;
		}

		const char *ptr1 = firstCoordinate.c_str();
		const char *ptr2 = secCoordinate.c_str();

		first.setX(first.convertFromCharToInt(*ptr1));
		first.setY(first.convertFromCharToNum(*(ptr1+1)));

		if(!checkIfItAPlayerRemovel(player,first)){
			cerr << "Invalid move; the game awaits a valid move.\n";
			continue;
		}
		sec.setX(sec.convertFromCharToInt(*ptr2));
		sec.setY(sec.convertFromCharToNum(*(ptr2+1)));

		if(!checkIfItAFreeCoordinate(sec)){
			cerr << "Invalid move; the game awaits a valid move.\n";
			continue;
		}
		if(!checkForTrueJunctions(first,sec)){
			cerr << "Invalid move; the game awaits a valid move.\n";
			continue;
		}
		return;

	}
}


/******************** checkIfItAPlayerRemovel method **************************/
bool Board::checkIfItAPlayerRemovel(const Player &player,const Point &point)const{

	//this function is checking if the coordinate at the board are taking by player

	if((point.getX()<8 && point.getX()>=0) || (point.getY()<8 && point.getY()>=0)){
		if(board[(int)point.getY()][(int)point.getX()]==player.getColor()) return true;
	}
	return false;

}


/******************** checkIfItAFreeCoordinate method **************************/
bool Board::checkIfItAFreeCoordinate(const Point &point)const{

	//this function is checking if the coordinate at the board are free

	if((point.getX()<8 && point.getX()>=0) || (point.getY()<8 && point.getY()>=0)){
		if(board[(int)point.getY()][(int)point.getX()]=='O') return true;
	}
	return false;
}

/******************** removeDisc method **************************/
void Board::removeDisc(Player &play,Point &temp){

	bool flag = false;
	DiscTool discTool(-1,-1); //Initialize the disctool

	if(checkIfItAPlayerRemovel(play,temp)){
		setCharBoardCordinate('O',temp);
		return;
	}
	else { cerr << "Invalid move; the game awaits a valid move.\n"; getPoints(flag,temp,play);}

	play.setDisc(discTool,play.emptySpotForDisc(temp));

}

/******************** checkForStrike method **************************/
bool Board::checkForStrike(const Point &a,const char &letter)const{

	//this function are checking for strikes in a row or col

	int cnt=0;
	bool flag=true;

	for(int j=0;j<SIZE;j++){

		if(a.getY()==3){ //if is the row 3 its can count a non strikes discs so thats why i split it to two options
			if((board[(int)a.getY()][j]==letter)&&flag) cnt++;
			else flag=false;
		}
		else if(board[(int)a.getY()][j]==letter)
			cnt++;

		if(cnt==3)
			return true;
	}

	cnt=0;
	flag=true;

	for(int i=0;i<SIZE;i++){

		if(a.getX()==3){ //if is the col 3
			if((board[i][(int)a.getX()]==letter)&&flag) cnt++;
			else flag=false;
		}
		else if(board[i][(int)a.getX()]==letter) cnt++;

		if(cnt==3)
			return true;
	}
	return false;

}

/******************** checkForTrueJunctions method **************************/
bool Board::checkForTrueJunctions(Point &currCoor,Point &nextCoor){


	//this function are checking all the combinations who can assume for a neighbors

	while(true){

		double distanceX = abs(nextCoor.getX()-currCoor.getX());
		double distanceY = abs(nextCoor.getY()-currCoor.getY());

		if(currCoor.getX()!=3 && currCoor.getY()!=3){ //Special treat for the 3rd row and col

			if(currCoor.getY()==0 || currCoor.getY()==6){
				if(distanceX==3 || distanceY==3) return true;

			}
			if(currCoor.getY()==1 || currCoor.getY()==5){
				if(distanceX==2 || distanceY==2) return true;

			}

			if(currCoor.getY()==2 || currCoor.getY()==4){
				if(distanceX==1 || distanceY==1){
					if(!nextCoor.equal(1,3) && !nextCoor.equal(3,3) && !nextCoor.equal(5,3)) return true;

				}
			}
		}

		if(currCoor.getX()==3){
			if(distanceY<=1){

				if(currCoor.getY()==0 || currCoor.getY()==6){
					if(distanceX==3 || distanceX==0) {
						if(!nextCoor.equal(0,3) && !nextCoor.equal(6,3))return true;
					}
				}
				if(currCoor.getY()==1 || currCoor.getY()==5){
					if(distanceX==2 || distanceX==0){
						if(!nextCoor.equal(3,1) && !nextCoor.equal(5,3))return true;
					}
				}
				if(currCoor.getY()==2 || currCoor.getY()==4){
					if(distanceX==1 || distanceX==0){
						if(!nextCoor.equal(2,3) && !nextCoor.equal(4,3))return true;
					}
				}


			}
		}

		if(currCoor.getY()==3){

			if(distanceX<=1){

				if(currCoor.getX()==0 || currCoor.getX()==6){
					if(distanceY==3 || distanceY==0) return true;
				}
				if(currCoor.getX()==1 || currCoor.getX()==5){
					if(distanceY==2 || distanceY==0) return true;
				}
				if(currCoor.getX()==2 || currCoor.getX()==4){
					if(distanceY==1 || distanceY==0){
						if(!nextCoor.equal(3,2) && !nextCoor.equal(3,4)) return true;
					}
				}
			}
		}

		return false;
	}
}

/******************** setCharBoardCordinate method **************************/
void Board::setCharBoardCordinate(const char &someChar,const Point &location) {
	board[(int)location.getY()][(int)location.getX()] = someChar;
}

/******************** message method **************************/
void Board::message(const char &wins,const char &lost)const{
	cout << lost<<": QUIT"<< endl;
	cout << wins << " wins the game.";
}

/******************** getCharInCordinate method **************************/
char Board::getCharInCordinate(const Point &location)const {
	return board[(int)location.getX()][(int)location.getY()];
}

/******************** initilaizeBoard method **************************/
void Board::initilaizeBoard(){

	for(int i=0;i<SIZE;i++){
		for(int j=0;j<SIZE;j++){
			if(i==0||i==6){
				if(j==0||j==3||j==6)
					board[i][j]='O';
				else board[i][j]='-';
			}
			if(i==1||i==5){
				if(j==1||j==3||j==5)
					board[i][j]='O';
				else board[i][j]='-';
			}
			if(i==2||i==4){
				if(j==2||j==3||j==4)
					board[i][j]='O';
				else board[i][j]='-';
			}
			if(i==3){
				if(j==3)
					board[i][j]='-';
				else board[i][j]='O';
			}

		}
	}
}

/******************** printBoard method **************************/
void Board::printBoard()const{

	for(int i=0;i<SIZE;i++){
		for(int j=0;j<SIZE;j++){
			cout << board[i][j];
			if(j!=SIZE-1) cout << " ";
		}
		cout << endl;
	}
}

